// Body.js
import React from 'react';

function Body(props) {
    return (
        <p>{props.comment}</p>
    );
}

export default Body;
